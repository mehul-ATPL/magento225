<?php
/**
 * Template Name: 1 Column
 */

get_template_part('index');
